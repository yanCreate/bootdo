package com.bootdo.common.utils;

public class Base64Utils {
	
}
